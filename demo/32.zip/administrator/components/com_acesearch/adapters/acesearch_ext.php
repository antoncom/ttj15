<?php
/**
* @version		1.5.0
* @package		AceSearch
* @subpackage	AceSearch
* @copyright	2009-2011 JoomAce LLC, www.joomace.net
* @license		GNU/GPL http://www.gnu.org/copyleft/gpl.html
*/

// No permission
defined('_JEXEC') or die('Restricted Access');

// AceSearch extension installation adapater
class JInstallerAcesearch_Ext extends JObject {

	function __construct(&$parent) {
		$this->parent =& $parent;
	}

	function install() {		
		// Get the extension manifest object
		$manifest =& $this->parent->getManifest();
		$this->manifest =& $manifest->document;
		
		// Set the extension's name
		$name =& $this->manifest->getElementByPath('name');
		$name = JFilterInput::clean($name->data(), 'string');
		$this->parent->set('name', $name);
		
		// Set the extension's description
        $description = & $this->manifest->getElementByPath('description');
        if (is_a($description, 'JSimpleXMLElement')) {
            $this->parent->set('message', $description->data());
        } else {
            $this->parent->set('message', '');
        }

		// Set the installation path
		$this->parent->setPath('extension_root', JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesearch'.DS.'extensions');
		
		/**
		* ---------------------------------------------------------------------------------------------
		* Filesystem Processing Section
		* ---------------------------------------------------------------------------------------------
		*/
		
		// If the extension directory does not exist, lets create it
        $created = false;
        if (!file_exists($this->parent->getPath('extension_root'))) {
            if (!$created = JFolder::create($this->parent->getPath('extension_root'))) {
                $this->parent->abort(JText::_('AceSearch Extension').' '.JText::_('Install').': '.JText::_('Failed to create directory').': "'.$this->parent->getPath('extension_root').'"');
                return false;
            }
        }

        if ($created) {
            $this->parent->pushStep(array ('type' => 'folder', 'path' => $this->parent->getPath('extension_root')));
        }
		
		// Copy all necessary files
		$element =& $this->manifest->getElementByPath('files');
		if ($this->parent->parseFiles($element, -1) === false) {
            // Install failed, roll back changes
            $this->parent->abort();
            return false;
        }
		
		// If there is an install file, lets copy it.
        $installScriptElement =& $this->manifest->getElementByPath('installfile');
        if (is_a($installScriptElement, 'JSimpleXMLElement')) {
            // Make sure it hasn't already been copied (this would be an error in the xml install file)
            if (!file_exists($this->parent->getPath('extension_root').DS.$installScriptElement->data()))
            {
                $path['src']	= $this->parent->getPath('source').DS.$installScriptElement->data();
                $path['dest']	= $this->parent->getPath('extension_root').DS.$installScriptElement->data();
                if (!$this->parent->copyFiles(array ($path))) {
                    // Install failed, rollback changes
                    $this->parent->abort(JText::_('AceSearch Extension').' '.JText::_('Install').': '.JText::_('Could not copy PHP install file.'));
                    return false;
                }
            }
            $this->set('install.script', $installScriptElement->data());
        }

        // If there is an uninstall file, lets copy it.
        $uninstallScriptElement =& $this->manifest->getElementByPath('uninstallfile');
        if (is_a($uninstallScriptElement, 'JSimpleXMLElement')) {
            // Make sure it hasn't already been copied (this would be an error in the xml install file)
            if (!file_exists($this->parent->getPath('extension_root').DS.$uninstallScriptElement->data()))
            {
                $path['src']	= $this->parent->getPath('source').DS.$uninstallScriptElement->data();
                $path['dest']	= $this->parent->getPath('extension_root').DS.$uninstallScriptElement->data();
                if (!$this->parent->copyFiles(array ($path))) {
                    // Install failed, rollback changes
                    $this->parent->abort(JText::_('AceSearch Extension').' '.JText::_('Install').': '.JText::_('Could not copy PHP uninstall file.'));
                    return false;
                }
            }
        }
		
		/**
		* ---------------------------------------------------------------------------------------------
		* Database Processing Section
		* ---------------------------------------------------------------------------------------------
		*/
		$db =& JFactory::getDBO();
		
		/*
        * Let's run the install queries for the component
        *	If backward compatibility is required - run queries in xml file
        *	If Joomla 1.5 compatible, with discreet sql files - execute appropriate
        *	file for utf-8 support or non-utf-8 support
        */
        $result = $this->parent->parseQueries($this->manifest->getElementByPath('install/queries'));
        if ($result === false) {
            // Install failed, rollback changes
            $this->parent->abort(JText::_('AceSearch Extension').' '.JText::_('Install').': '.JText::_('SQL Error')." ".$db->stderr(true));
            return false;
        } elseif ($result === 0) {
            // no backward compatibility queries found - try for Joomla 1.5 type queries
            // second argument is the utf compatible version attribute
            $utfresult = $this->parent->parseSQLFiles($this->manifest->getElementByPath('install/sql'));
            if ($utfresult === false) {
                // Install failed, rollback changes
                $this->parent->abort(JText::_('AceSearch Extension').' '.JText::_('Install').': '.JText::_('SQLERRORORFILE')." ".$db->stderr(true));
                return false;
            }
        }
		//Get Cilent 
		$client =& $this->manifest->getElementByPath('client');
		$client = JFilterInput::clean($client->data(), 'string');
		
		// Get extension
		$extension = preg_replace('/.xml$/', '', basename($this->parent->getPath('manifest')));
		
		// Check if extension exists and upgrade is performed
		$db->setQuery("SELECT name, params FROM #__acesearch_extensions WHERE extension = '{$extension}'");
		$existing = $db->loadObject();
		
		$installation = false;
		
		// Existing Install
		if (!is_null($existing)) {
			if ($existing->name == "") {		
				$old_p = new JParameter($existing->params);
				$new_p = new JParameter(self::_getDefaultParams());
				$new_p->set('custom_name', $old_p->get('custom_name', ''));
				$params = $new_p->toString();
				
				$db->setQuery("UPDATE #__acesearch_extensions SET name = '{$name}', params = '{$params}', client = '{$client}' WHERE extension = '{$extension}'");
				$db->query();
				
				$installation = true;
			}
		}
		// New Install
		else {
			JTable::addIncludePath(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_acesearch'.DS.'tables');
			$row =& JTable::getInstance('AcesearchExtensions', 'Table');	
			$row->name 			= $name;
			$row->extension 	= $extension;
			$row->client		= $client;
			$row->params 		= self::_getDefaultParams();
			$row->store();
			
			$installation = true;
		}
		
		/**
		* ---------------------------------------------------------------------------------------------
		* Custom Installation Script Section
		* ---------------------------------------------------------------------------------------------
		*/

		/*
		* If we have an install script, lets include it, execute the custom
		* install method, and append the return value from the custom install
		* method to the installation message.
		*/
		if ($this->get('install.script')) {
			if (is_file($this->parent->getPath('extension_root').DS.$this->get('install.script'))) {
				ob_start();
				ob_implicit_flush(false);
				require_once ($this->parent->getPath('extension_root').DS.$this->get('install.script'));
				if (function_exists('com_install')) {
					if (com_install() === false) {
						$this->parent->abort(JText::_('AceSearch Extension').' '.JText::_('Install').': '.JText::_('Custom install routine failure'));
						return false;
					}
				}
				$msg = ob_get_contents();
				ob_end_clean();
				if ($msg != '') {
					$this->parent->set('extension.message', $msg);
				}
			}
		}
		
		/**
		* ---------------------------------------------------------------------------------------------
		* Finalization and Cleanup Section
		* ---------------------------------------------------------------------------------------------
		*/
		
		// Lastly, we will copy the manifest file to its appropriate place.
		if (!$this->parent->copyManifest(-1)) {
			// Install failed, rollback changes
			$this->parent->abort(JText::_('Could not copy setup file'));
			return false;
		}
		return true;
		
	}
    
	// Get default params
    function _getDefaultParams() {
        $element = $this->manifest->getElementByPath('install/defaultparams');
        
		$params = array();
		$params[] = 'handler=1';
		$params[] = 'custom_name=';
		$params[] = 'access=0';
		$params[] = 'result_limit=';
		
		if (is_a($element, 'JSimpleXMLElement') && count($element->children())) {
			$defaultParams = $element->children();
			if (count($defaultParams) != 0) {
				foreach ($defaultParams as $param) {
					if ($param->name() != 'defaultparam') {
						continue;
					}
					
					$name = $param->attributes('name');
					$value = $param->attributes('value');
					
					$params[] = $name.'='.$value;
				}
			}
		}
		
		return implode("\n", $params);
    }
}