
hs.outlineType = 'rounded-white';
hs.wrapperClassName = 'draggable-header';
hs.showCredits = false;

/*hs.dimmingOpacity = 0.4;
hs.maxWidth = 800;
hs.maxHeight = 200;
hs.maxHeight = 600;
hs.align = 'auto';
hs.allowWidthReduction = true;*/