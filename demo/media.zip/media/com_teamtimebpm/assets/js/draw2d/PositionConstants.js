draw2d.PositionConstants=function()
{
};

draw2d.PositionConstants.NORTH =  1;
draw2d.PositionConstants.SOUTH =  4;
draw2d.PositionConstants.WEST  =  8;
draw2d.PositionConstants.EAST  = 16;
