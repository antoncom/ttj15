//
// package draw2d
//

var draw2d = new Object();