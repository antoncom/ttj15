<?php
/*----------------------------------------------------------------------
#Youjoomla YJ Booking Module 1.0
# ----------------------------------------------------------------------
# Copyright (C) 2007 You Joomla. All Rights Reserved.
# Coded by: NEO
# License: Youjoomla LLC
# Website: http://www.youjoomla.com
------------------------------------------------------------------------*/
  defined( '_JEXEC' ) or die( 'Direct Access to this location is not allowed.');







$destination_pack_legend = $params->get( 'destination_pack_legend',"Choose your destination:" );
$destination_pack_label = $params->get( 'destination_pack_label',"Destination Package:" );
$personal_info_legend = $params->get( 'personal_info_legend',"Personal Information" );
$first_name_label = $params->get( 'first_name_label',"Name:" );
//$name_validator = $params->get( 'name_validator' );
$surname_label = $params->get( 'surname_label',"Surname:" );
//$surname_validator = $params->get( 'surname_validator' );
$email_label = $params->get( 'email_label',"E-mail:" );
//$email_validator = $params->get( 'email_validator' );
$phone_label = $params->get( 'phone_label',"Phone:" );
//$phone_validator = $params->get( 'phone_validator' );
$arrival_legend = $params->get( 'arrival_legend',"Check-in:" );
$day_of_arrival_label = $params->get( 'day_of_arrival_label',"Day:" );
$month_of_arrival_label = $params->get( 'month_of_arrival_label',"Month:" );
$year_of_arrival_label = $params->get( 'year_of_arrival_label',"Year" );
$departure_legend = $params->get( 'departure_legend',"Check-out:" );
$day_of_departure_label = $params->get( 'day_of_departure_label',"Day:" );
$month_of_departure_label = $params->get( 'month_of_departure_label',"Month" );
$year_of_departure_label = $params->get( 'year_of_departure_label',"Year:" );
$accomodation_legend = $params->get( 'accomodation_legend',"Accomodation" );
$type_of_room_label = $params->get( 'type_of_room_label',"Type of Room:" );
$num_g_label = $params->get( 'num_g_label',"���������� �������:" );
//$num_g_validator = $params->get( 'num_g_validator' );
$additional_info_legend = $params->get( 'additional_info_legend',"Additional Information" );
$submit_button = $params->get( 'submit_button',"Submit Form" );
$reset_button = $params->get( 'reset_button',"Reset Form" );

$your_email = $params->get( 'your_email',"change@toyourmail.com" );
$SMTP_email = $params->get( 'SMTP_email',"your@smtpusername.com" );
$email_subject = $params->get( 'email_subject',"New Booking Information" );

$show_accordion = $params->get( 'show_accordion',0 );
$ismooloaded = $params->get ( 'ismooloaded',0 );
$compress = $params->get ( 'compress',0 );
$sentmsg1 =  $params->get ( 'sentmsg1',"Thank you for your inquiry about." );
$sentmsg2 =  $params->get ( 'sentmsg2',"We will contact you back." );

if($compress == 1){
$mooext = 'php';
}else{
$mooext = 'css';
}


//  do not edit below this line


include ("modules/mod_yj_booking/getmail.php");

//get the titles

  
  
function getTitles($params){

  $now 		    = date('Y-m-d H:i:s');
  $database 	=& JFactory::getDBO();
  $nullDate 	= $database->getNullDate();


$work_section=$params->get('work_section',1);
$query = 'SELECT title ,sectionid FROM #__content WHERE (state=1) and (sectionid='.$work_section.') ORDER by ordering';
$database->setQuery($query);
$titles = $database->loadObjectList();

foreach ( $titles as $row ) {

echo "<option value=\"$row->title\"   selected=\"selected\" >".$row->title."</option>";

}
}
?>

<script type="text/javascript">
var formlanguage = "en-US"; // set default form language
</script>

   


<div id="yj_booking">

    <?php if($show_accordion ==2) { ?>

	<!-- reservation form begin -->
	<form id="ReservationForm"  method="post" action="<?php echo stayThere(); ?>"  onsubmit="return validate();" onreset="resetForm();">
    
		<div class="reservation">
			<fieldset class="destination_pack_legend">
            <legend id="destination_pack_legend"><?php echo $destination_pack_legend ?></legend>
<div>
					<label for="destination_pack" id="destination_pack_label"><?php echo $destination_pack_label ?></label>
					<select name="destination_pack" id="destination_pack" >
					<?php getTitles($params);?>
					</select>
                    <div id="MojInfo"></div>
				</div>
			</fieldset>
            </div>

		<div class="reservation">
			<fieldset class="personal-data">
            	<legend id="personal_data"><?php echo $personal_info_legend ?></legend>

				<div>
					<label for="first_name" id="first_name_label"><?php echo $first_name_label ?></label>
                    
					<input type="text"  name="first_name" id="first_name"  value="" onkeyup="hideWarning('name_validator');" />
					<div id="name_validator" class="validator display-none"><!-- --></div>
				</div>
				<div>
					<label for="surname" id="surname_label"><?php echo $surname_label ?></label>
					<input type="text"  name="surname" id="surname" value="" onkeyup="hideWarning('surname_validator');" />
					<div id="surname_validator" class="validator display-none"><!-- --></div>
				</div>
				<br class="break" />
				<div>
					<label for="email" id="email_label"><?php echo $email_label ?></label>
					<input type="text" name="email" id="email" value="" onkeyup="hideWarning('email_validator');" />
					<div id="email_validator" class="validator display-none"><!-- --></div>
				</div>
				<div>
					<label for="phone" id="phone_label"><?php echo $phone_label ?></label>
					<input type="text" name="phone" id="phone" value="" onkeyup="hideWarning('phone_validator');" class="text-align-right" />
					<div id="phone_validator" class="validator display-none"><!-- --></div>

		
	                
				</div>
			</fieldset>
			
            
                
            
			<fieldset>
				<legend id="arrival_legend"><?php echo $arrival_legend ?></legend>
                
				<div>
				
<label for="day_of_arrival" id="day_of_arrival_label"><?php echo $day_of_arrival_label ?></label>
	<select name="day_of_arrival" id="day_of_arrival">
						<option  value="1" selected="selected">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
					</select>
				</div>
				<div>
					<label for="month_of_arrival" id="month_of_arrival_label"><?php echo $month_of_arrival_label ?></label>
					<select name="month_of_arrival" id="month_of_arrival">
						<option value="January" selected="selected">January</option>
						<option value="February">February</option>
						<option value="March">March</option>
						<option value="April">April</option>
						<option value="May">May</option>
						<option value="June">June</option>
						<option value="July">July</option>
						<option value="August">August</option>
						<option value="September">September</option>
						<option value="October">October</option>
						<option value="November">November</option>
						<option value="November">November</option>
					</select>
				</div>
				<div>
					<label for="year_of_arrival" id="year_of_arrival_label"><?php echo $year_of_arrival_label ?></label>
					<select name="year_of_arrival" id="year_of_arrival">
						<option value="2007" selected="selected">2007</option>
						<option value="2008">2008</option>
						<option value="2009">2009</option>
						<option value="2010">2010</option>
					</select>
				</div>
			</fieldset>
			
     
			<fieldset>
				<legend id="departure_legend"><?php echo $departure_legend ?></legend>
				<div>
<label for="day_of_departure" id="day_of_departure_label"><?php echo $day_of_departure_label ?></label>
					<select name="day_of_departure" id="day_of_departure">
						<option value="1" selected="selected">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
					</select>
				</div>
				<div>
					<label for="month_of_departure" id="month_of_departure_label"><?php echo $month_of_departure_label ?></label>
					<select name="month_of_departure" id="month_of_departure">
						<option value="January" selected="selected">January</option>
						<option value="February">February</option>
						<option value="March">March</option>
						<option value="April">April</option>
						<option value="May">May</option>
						<option value="June">June</option>
						<option value="July">July</option>
						<option value="August">August</option>
						<option value="September">September</option>
						<option value="October">October</option>
						<option value="November">November</option>
						<option value="November">November</option>
					</select>
				</div>
				<div>
					<label for="year_of_departure" id="year_of_departure_label"><?php echo $year_of_departure_label ?></label>
					<select name="year_of_departure" id="year_of_departure">
						<option value="2007" selected="selected">2007</option>
						<option value="2008">2008</option>
						<option value="2009">2009</option>
						<option value="2010">2010</option>
					</select>
				
				</div>
			</fieldset>
	
			<fieldset>
				<legend id="accomodation_legend"><?php echo $accomodation_legend ?></legend>
				<div>
					<label for="type_of_room" id="type_of_room_label"><?php echo $type_of_room_label ?></label>
					<select  name="type_of_room" id="type_of_room">
						<option value="single" selected="selected">single</option>
						<option value="double">double</option>
						<option value="apartment">apartment</option>
					</select>
				</div>
				<div>
					<label for="num_g" id="num_g_label"><?php echo $num_g_label ?></label>
					<input type="text" name="num_g" id="num_g" size="3" maxlength="3" value="" onkeyup="hideWarning('num_g_validator');"  class="text-align-right" />
					<div id="num_g_validator" class="validator display-none"><!-- --></div>
				</div>
			</fieldset>
		
			<fieldset>
				<legend id="additional_info_legend"><?php echo $additional_info_legend ?></legend>
				<textarea name="additional_info" id="additional_info"  rows="" cols=""></textarea>
			</fieldset>
		
			<fieldset>
                    

                <input type="submit" name="salji"  id="submit_button" value="<?php echo $submit_button ?>" />
				<input type="reset" id="reset_button"  title="" value="<?php echo $reset_button ?> "  />
			</fieldset>
			<div class="display-none">
				<input type="hidden" id="date" />
				<input type="hidden" name="Subject" value="RESERVATION INFORMATION" />
				<input type="text" id="generatedantispamcode" name="generatedantispamcode"/>
				<input type="text" id="submittedantispamcode" name="submittedantispamcode"/>
				<textarea id="reservation_information" name="RESERVATION_INFORMATION" cols="" rows=""></textarea>
			</div>
		</div>
	</form>
	<!-- reservation form end --><?php } ?>
    
    
    
    
    
    <?php if($show_accordion ==1) { ?>
<script type="text/javascript">
        window.addEvent('domready', function() {
	var accordion = new Accordion($$('.toggler'),$$('.element'), {
		opacity: 0
		//onActive: function(toggler) { toggler.setStyle('color', '#000'); },
		//onBackground: function(toggler) { toggler.setStyle('color', '#fff'); }
	});
});
                
  </script>
  	<!-- reservation form begin -->
	<form id="ReservationForm"  method="post" action="<?php echo stayThere(); ?>"  onsubmit="return validate();" onreset="resetForm();">
    
		<div class="reservation">
			<fieldset class="destination_pack_legend">
            <legend class="toggler"><?php echo $destination_pack_legend ?></legend>
            <div class="element">
<div>
					<label for="destination_pack" id="destination_pack_label"><?php echo $destination_pack_label ?></label>
					<select name="destination_pack" id="destination_pack" >
					<?php getTitles($params);?>
					</select>
                    <div id="MojInfo"></div>
				</div>
                </div>
			</fieldset>
            </div>

		<div class="reservation">
			<fieldset class="personal-data">
            	<legend class="personal_data"><?php echo $personal_info_legend ?></legend>


				<div>
					<label for="first_name" id="first_name_label"><?php echo $first_name_label ?></label>
                    
					<input type="text"  name="first_name" id="first_name"  value="" onkeyup="hideWarning('name_validator');" />
					<div id="name_validator" class="validator display-none"><!-- --></div>
				</div>
				<div>
					<label for="surname" id="surname_label"><?php echo $surname_label ?></label>
					<input type="text"  name="surname" id="surname" value="" onkeyup="hideWarning('surname_validator');" />
					<div id="surname_validator" class="validator display-none"><!-- --></div>
				</div>
				<br class="break" />
				<div>
					<label for="email" id="email_label"><?php echo $email_label ?></label>
					<input type="text" name="email" id="email" value="" onkeyup="hideWarning('email_validator');" />
					<div id="email_validator" class="validator display-none"><!-- --></div>
				</div>
				<div>
					<label for="phone" id="phone_label"><?php echo $phone_label ?></label>
					<input type="text" name="phone" id="phone" value="" onkeyup="hideWarning('phone_validator');" class="text-align-right" />
					<div id="phone_validator" class="validator display-none"><!-- --></div>

		
	                
				</div>
			</fieldset>
			
            <fieldset>
				<legend id="accomodation_legend"><?php echo $accomodation_legend ?></legend>
				<div>
					<label for="type_of_room" id="type_of_room_label"><?php echo $type_of_room_label ?></label>
					<select  name="type_of_room" id="type_of_room">
						<option value="single" selected="selected">single</option>
						<option value="double">double</option>
						<option value="apartment">apartment</option>
					</select>
				</div>
				<div>
					<label for="num_g" id="num_g_label"><?php echo $num_g_label ?></label>
					<input type="text" name="num_g" id="num_g" size="3" maxlength="3" value="" onkeyup="hideWarning('num_g_validator');"  class="text-align-right" />
					<div id="num_g_validator" class="validator display-none"><!-- --></div>
				</div>
			</fieldset>
                
            
			<fieldset>
				<legend class="toggler"><?php echo $arrival_legend ?></legend>
                <div class="element">
				<div>
				
<label for="day_of_arrival" id="day_of_arrival_label"><?php echo $day_of_arrival_label ?></label>
                   


                    
                    
				
	<select name="day_of_arrival" id="day_of_arrival">
						<option  value="1" selected="selected">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
					</select>
				</div>
				<div>
					<label for="month_of_arrival" id="month_of_arrival_label"><?php echo $month_of_arrival_label ?></label>
					<select name="month_of_arrival" id="month_of_arrival">
						<option value="January" selected="selected">January</option>
						<option value="February">February</option>
						<option value="March">March</option>
						<option value="April">April</option>
						<option value="May">May</option>
						<option value="June">June</option>
						<option value="July">July</option>
						<option value="August">August</option>
						<option value="September">September</option>
						<option value="October">October</option>
						<option value="November">November</option>
						<option value="November">November</option>
					</select>
				</div>
				<div>
					<label for="year_of_arrival" id="year_of_arrival_label"><?php echo $year_of_arrival_label ?></label>
					<select name="year_of_arrival" id="year_of_arrival">
						<option value="2007" selected="selected">2007</option>
						<option value="2008">2008</option>
						<option value="2009">2009</option>
						<option value="2010">2010</option>
					</select>
					
                  
				</div>
             </div>
                
                	
                
			</fieldset>
			
     
			<fieldset>
				<legend class="toggler"><?php echo $departure_legend ?></legend>
                <div class="element">
				<div>
                
                
				
<label for="day_of_departure" id="day_of_departure_label"><?php echo $day_of_departure_label ?></label>

             
                                      
					
					<select name="day_of_departure" id="day_of_departure">
						<option value="1" selected="selected">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
						<option value="16">16</option>
						<option value="17">17</option>
						<option value="18">18</option>
						<option value="19">19</option>
						<option value="20">20</option>
						<option value="21">21</option>
						<option value="22">22</option>
						<option value="23">23</option>
						<option value="24">24</option>
						<option value="25">25</option>
						<option value="26">26</option>
						<option value="27">27</option>
						<option value="28">28</option>
						<option value="29">29</option>
						<option value="30">30</option>
						<option value="31">31</option>
					</select>
				</div>
				<div>
					<label for="month_of_departure" id="month_of_departure_label"><?php echo $month_of_departure_label ?></label>
					<select name="month_of_departure" id="month_of_departure">
						<option value="January" selected="selected">January</option>
						<option value="February">February</option>
						<option value="March">March</option>
						<option value="April">April</option>
						<option value="May">May</option>
						<option value="June">June</option>
						<option value="July">July</option>
						<option value="August">August</option>
						<option value="September">September</option>
						<option value="October">October</option>
						<option value="November">November</option>
						<option value="November">November</option>
					</select>
				</div>
				<div>
					<label for="year_of_departure" id="year_of_departure_label"><?php echo $year_of_departure_label ?></label>
					<select name="year_of_departure" id="year_of_departure">
						<option value="2007" selected="selected">2007</option>
						<option value="2008">2008</option>
						<option value="2009">2009</option>
						<option value="2010">2010</option>
					</select>
				
				</div>
                </div>
			</fieldset>
	
			
		<div class="reservation>">
			<fieldset>
				<legend class="toggler"><?php echo $additional_info_legend ?></legend>
                <div class="element">
				<textarea name="additional_info" id="additional_info" cols="" style="width: 100%;"  rows=""></textarea>
                </div>
			</fieldset>
		</div>
			<fieldset>
                    

                <input type="submit" name="salji" id="submit_button" value="<?php echo $submit_button ?>" />
				<button type="reset" id="reset_button" title=""><?php echo $reset_button ?></button>
			</fieldset>
			<div class="display-none">
				<input type="hidden" id="date" />
				<input type="hidden" name="Subject" value="RESERVATION INFORMATION" />
				<input type="text" id="generatedantispamcode" name="generatedantispamcode"/>
				<input type="text" id="submittedantispamcode" name="submittedantispamcode"/>
				<textarea id="reservation_information" name="RESERVATION_INFORMATION" cols="" rows=""></textarea>
			</div>
		</div>
	</form>
  
  
  
  
  
  
  
  
  
  
  
  
  <?php } ?>
    
    
    
    
    </div>