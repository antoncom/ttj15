<?php 
/*----------------------------------------------------------------------
#Youjoomla YJ Booking Module 1.0
# ----------------------------------------------------------------------
# Copyright (C) 2007 You Joomla. All Rights Reserved.
# Coded by: NEO
# License: Youjoomla LLC
# Website: http://www.youjoomla.com
------------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted index access' );

echo "<!-- http://www.Youjoomla.com  YJ Booking Module for Joomla 1.5 starts here -->	";
echo "<script type='text/javascript' src='".JURI::base()."/modules/mod_yj_booking/files/form.js'></script>\n";
$linktag_yj_book="<link rel='stylesheet' type='text/css' href='".JURI::base()."/modules/mod_yj_booking/files/form_css.css'/>\n";

if ($ismooloaded == 1) {
$linktag_yj_book="<link rel='stylesheet' type='text/css' href='".JURI::base()."/modules/mod_yj_booking/files/mootools.".$mooext."'/>\n";
}





$mainframe->addCustomHeadTag($linktag_yj_book);



//send mail 

 if(isset($_POST['salji'])){
// get posted data into local variables
$EmailFrom = $SMTP_email;
$EmailTo = $your_email ;
$Subject = $email_subject ;

// FORM VARS
$destination_pack = Trim(stripslashes($_POST['destination_pack'])); 
$first_name = Trim(stripslashes($_POST['first_name'])); 
$surname = Trim(stripslashes($_POST['surname'])); 
$email = Trim(stripslashes($_POST['email'])); 
$phone = Trim(stripslashes($_POST['phone'])); 
$day_of_arrival = Trim(stripslashes($_POST['day_of_arrival'])); 
$month_of_arrival = Trim(stripslashes($_POST['month_of_arrival'])); 
$year_of_arrival = Trim(stripslashes($_POST['year_of_arrival'])); 
$day_of_departure = Trim(stripslashes($_POST['day_of_departure'])); 
$month_of_departure = Trim(stripslashes($_POST['month_of_departure'])); 
$year_of_departure = Trim(stripslashes($_POST['year_of_departure'])); 
$type_of_room = Trim(stripslashes($_POST['type_of_room'])); 
$num_g = Trim(stripslashes($_POST['num_g'])); 
$additional_info = Trim(stripslashes($_POST['additional_info'])); 

// validation
$validationOK=true;
if (!$validationOK) {
 echo '<div id="log">';
    print "Your Message wa not sent.<br /> Please check module settings";
	echo '</div>';  exit;
}
// prepare email body text
$Body = "";
$Body .= "\n\nDestination Package:";
$Body .= $destination_pack;
$Body .= "\n\nFirst Name:";
$Body .= $first_name;
$Body .= "\n\nSurname:";
$Body .= $surname;
$Body .= "\n\nE-Mail:";
$Body .= $email;
$Body .= "\n\nPhone:";
$Body .= $phone;
$Body .= "\n\nDay of arrival:";
$Body .= $day_of_arrival;
$Body .= "\n\nMonth of arrival:";
$Body .= $month_of_arrival;
$Body .= "\n\nYear of arrival:";
$Body .= $year_of_arrival;
$Body .= "\n\nDay of departure:";
$Body .= $day_of_departure;
$Body .= "\n\nMonth of departure: ";
$Body .= $month_of_departure;
$Body .= "\n\nYear of departure:";
$Body .= $year_of_departure;
$Body .= "\n\nType of room:";
$Body .= $type_of_room;
$Body .= "\n\nNumber of guests:";
$Body .= $num_g;
$Body .= "\n\nAdditional info:";
$Body .= $additional_info;
$Body .= "\n";

// send email 
$success = mail($EmailTo, $Subject, $Body, "From: <$EmailFrom>");

// redirect to success page 
if ($success){

   echo '<div id="log">';
   echo "".$sentmsg1."&nbsp; <b>".$destination_pack."</b>.&nbsp;".$sentmsg2."";
    echo '</div>';
}
else{
  //print "<meta http-equiv=\"refresh\" content=\"0;URL=error.htm\">";
     echo '<div id="log">';
    print "Your Message wa not sent.<br /> Please check module settings";
	echo '</div>';
}
}

//  stay there 



function stayThere(){
$cururl_sendform = JRequest::getURI();
if(($pos = strpos($cururl_sendform, "index.php"))!== false){
$cururl_sendform = substr($cururl_sendform,$pos);
}
$cururl_sendform = JRoute::_($cururl_sendform);
return $cururl_sendform;
}


//echo '<pre>';      // Using PRE for readability
//print_r($_POST);
//echo '</pre>'; 
?>
